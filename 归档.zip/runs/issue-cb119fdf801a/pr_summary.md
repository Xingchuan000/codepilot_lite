# PR Summary

## Issue

Fixes: Add bug

## Summary

Repo safety denied: protected dirty path detected. Protected dirty files: .env

## Changes

- No changed files reported.

## Tests

- Status: skipped
- Command: `not run`
- Summary: Repo safety denied: protected dirty path detected. Protected dirty files: .env

## Evidence

- Report: `report.md`
- Patch: `changes.patch`
- Manifest: `artifact_manifest.json`
- Restore plan: `restore_plan.md`

## Safety

- No commit was created automatically.
- No push was performed.
- No pull request was created automatically.
- Original repo: `/private/var/folders/6m/t5xlqdcd2y3bkqmwpyg1n2yc0000gn/T/pytest-of-x1ngchuan/pytest-81/test_cli_protected_env_dirty_r0/repo`
- Effective repo: `/private/var/folders/6m/t5xlqdcd2y3bkqmwpyg1n2yc0000gn/T/pytest-of-x1ngchuan/pytest-81/test_cli_protected_env_dirty_r0/repo`
- Worktree used: no
- Worktree path: `none`
- Dirty policy: warn
- Baseline dirty: yes
- Safety decision: deny
- Safety reason: Repo safety denied: protected dirty path detected. Protected dirty files: .env
- Warning: Repo safety denied: protected dirty path detected. Protected dirty files: .env
- Warning: Dirty files: .env
