# Restore Plan

## Run
- Run ID: `issue-5af9f59e20ce`
- Original repo: `/private/var/folders/6m/t5xlqdcd2y3bkqmwpyg1n2yc0000gn/T/pytest-of-x1ngchuan/pytest-59/test_cli_protected_env_dirty_r0/repo`
- Effective repo: `/private/var/folders/6m/t5xlqdcd2y3bkqmwpyg1n2yc0000gn/T/pytest-of-x1ngchuan/pytest-59/test_cli_protected_env_dirty_r0/repo`
- Worktree used: no
- Baseline dirty: yes

## Patch
- Patch path: `none`
- Empty patch: unknown
- Patch SHA256: `none`
- Changed files:
  - none

## Worktree
- Worktree not used.

## Non-worktree recovery
- Review `changes.patch` first before touching the repository.
- Do not use commands that overwrite pre-existing user changes.
- Manually review the changed files listed above before applying any recovery action.
